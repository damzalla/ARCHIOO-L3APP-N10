package Main;


import Main.MyException.MonException;

public class Calculator {

    public double calcul(String op, double a, double b) throws MonException {
        return CalculatorConf.getOperation(op).calculer(a,b);
    }

}

    private static final Logger LOGGER = Logger.getLogger( ServiceCalculatrice.class.getName());

    private static ServerSocket server;
    private static int PORT=33001;

    public static void lunch() throws IOException, ClassNotFoundException, MonException {
        server = new ServerSocket(PORT);

        LOGGER.log(Level.INFO,"Server running");
        while(true) {
            Socket socket = server.accept();
            LOGGER.log(Level.INFO, "connexion established");

            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());


            Operation operation = (Operation) ois.readObject();
            LOGGER.log(Level.INFO, "Message received: " + operation);