package Main;

import Main.MyException.EnumException;
import Main.MyException.MonException;

import java.util.HashMap;
import java.util.Map;

public class CalculatorConf {

    private static Map<String, Operation> hm = new HashMap<>();

    public static Operation getOperation(String op) throws MonException{
        if (hm.containsKey(op)==false){
            throw new MonException(EnumException.UTILISATION_DE_DEUX.getCode(),EnumException.UTILISATION_DE_DEUX.getDefaultm());
        }

        return hm.get(op);
    }

    public static Map init(){
        hm = new HashMap<>();
        hm.put("+", new Addition());
        hm.put("/", new Division());
        return hm;
    }

}
