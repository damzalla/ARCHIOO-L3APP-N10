package Main.Properties;

import Main.Addition;
import Main.Division;
import Main.MyException.EnumException;
import Main.MyException.MonException;
import Main.Operation;

import java.util.HashMap;
import java.util.Map;

public class LangueConf {
    private static Map<String, String> hm = new HashMap<>();

    public static String getWord(String key) throws MonException {
        if (hm.containsKey(key)==false){
            throw new MonException(EnumException.UTILISATION_DE_UN.getCode(),EnumException.UTILISATION_DE_UN.getDefaultm());
        }
        return hm.get(key);
    }

    public static Map init (String key){
        if (key.contains("FR")){
            return initFR();
        }
        else {
            return initEN();
        }

    }

    private static Map initFR() {
        hm = new HashMap<>();
        hm.put("inputA","Entrez a: ");
        hm.put("operator", "\nEntrez l'opérateur + ou /: ");
        hm.put("inputB","\nEntrez b: ");


        return hm;
    }

    private static Map initEN(){
        hm = new HashMap<>();
        hm.put("inputA","Input A:");
        hm.put("operator", "Choose an operator + or /: ");
        hm.put("inputB","Input B:");
        return hm;
    }
}
