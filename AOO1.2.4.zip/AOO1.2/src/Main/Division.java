package Main;


import Main.MyException.EnumException;
import Main.MyException.MonException;

public class Division implements Operation{
    public double calculer (double a, double b) throws MonException {
        if (b==0){
            throw new MonException(EnumException.UTILISATION_DU_ZERO.getCode(),EnumException.UTILISATION_DU_ZERO.getDefaultm());
        }
        else return a/b;
    }
}
