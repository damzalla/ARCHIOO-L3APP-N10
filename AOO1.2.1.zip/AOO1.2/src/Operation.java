public interface Operation {
    public double calculer(double a, double b);
}
