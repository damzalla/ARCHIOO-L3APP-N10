public class Calculator {

    public double calcul(String op, double a, double b) {
        return CalculatorConf.getOperation(op).calculer(a,b);
    }

}
