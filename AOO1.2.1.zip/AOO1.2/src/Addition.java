public class Addition implements Operation{

    public double calculer(double a, double b){
        return a+b;
    }
}
