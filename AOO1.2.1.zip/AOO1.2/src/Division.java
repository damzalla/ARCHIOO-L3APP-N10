public class Division implements Operation{
    public double calculer (double a, double b){
        try {
            return a/b;
        } catch (Exception e) {
            System.out.println("Division by Zero");
        }
            return 0;
    }
}
