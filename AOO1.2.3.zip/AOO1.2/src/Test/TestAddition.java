package Test;

import Main.Calculator;
import Main.CalculatorConf;
import Main.MyException.MonException;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestAddition {

    @Test
    public void addsimple() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(9.0, c.calcul("+", 2, 7), 0.0000001);
    }

    @Test
    public void addnegative() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(-10.0,c.calcul("+",-3,-7),0.0000001);
    }

    @Test
    public void addNombreReel() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(2.5,c.calcul("+",1.25,1.25),0.0000001);
    }

    }


