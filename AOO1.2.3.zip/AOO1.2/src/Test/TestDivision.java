package Test;

import Main.Calculator;
import Main.CalculatorConf;
import Main.MyException.MonException;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDivision {

    @Test
    public void divSimple() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(2.0,c.calcul("/",10,5),0.0000001);
    }

    @Test
    public void divNegative() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(-5.0,c.calcul("/",10,-2),0.0000001);
    }

    @Test
    public void divNombreReel() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        assertEquals(2.5,c.calcul("/",5,2),0.0000001);
    }

    @Test(expected=MonException.class)
    public void testCalculator2() throws MonException {
        CalculatorConf.init();
        Calculator c = new Calculator();
        c.calcul("/",2,0);
    }




}
