package Main;

import Main.MyException.MonException;
import Main.Properties.LangueConf;

import java.util.Scanner;

public class CommandLine {
    public CommandLine() {
        Scan();

    }

    private double a=0,b=0;
    private String op;

    public void choixLangue(Scanner sc){
        System.out.println("FR ou EN ?");
        LangueConf.init(sc.next());
    }

    public void Scan (){


        Scanner sc = new Scanner(System.in);
        choixLangue(sc);
        try {
            System.out.println("\n"+LangueConf.getWord("inputA"));
            try {
                a=sc.nextDouble();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }


            System.out.println(LangueConf.getWord("operator"));
            op=String.valueOf(sc.next().charAt(0));

            System.out.println(LangueConf.getWord("inputB"));
            try {
                b=sc.nextDouble();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }finally {
                sc.close();
            }


            System.out.println(new Calculator().calcul(op,a,b));
        }
        catch (MonException e){
            System.out.println(e.getDefaultm());
        }
    }
}
