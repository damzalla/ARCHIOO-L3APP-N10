import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        CalculatorConf.init();
        IHM i = new IHM();

    }

    /*
        public static double addition(double a, double b) {
            return a+b;
      }

        /*public static double division(double a, double b) {
            if (b==0){
                System.out.println("Error division by 0");
                return 0;
            }
            return a/b;
        }

    public static double calculator(String s){
        if(s.isEmpty()){
            return 0;
        }

        if (s.contains("/")){
            String a = s.substring(0, s.indexOf('/'));
            String b = s.substring(s.indexOf('/')+1 );
            return Division.division(Double.parseDouble(a), Double.parseDouble(b));
        }

        if (s.contains("+")){
            String a = s.substring(0, s.indexOf('+'));
            String b = s.substring(s.indexOf('+')+1 );
            return Addition.addition(Double.parseDouble(a), Double.parseDouble(b));
        }

        System.out.println("Operation unknown");
        return 0.0;
    }

*/
}



