import MyException.MonException;

import java.util.Scanner;

public class CommandLine {
    public CommandLine() {
        Scan();
    }

    private double a=0,b=0;
    private String op;


    public void Scan (){
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Entrez a: ");
            try {
                a=sc.nextDouble();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }


            System.out.println("\nEntrez l'opérateur: ");
            op=String.valueOf(sc.next().charAt(0));

            System.out.println("\nEntrez b: ");
            try {
                b=sc.nextDouble();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }


            System.out.println(new Calculator().calcul(op,a,b));
        }
        catch (MonException e){
            System.out.println(e.getDefaultm());
        }
    }
}
