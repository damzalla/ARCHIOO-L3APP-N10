package MyException;

public class MonException extends Exception{
    private int code; private String defaultm;

    public MonException() {
        super();
    }

    public MonException(int code,String defaultm) {
        this.code=code;
        this.defaultm=defaultm;

    }
    public int getCode() {
        return code;
    }

    public void  setCode(int code) {
        this.code= code;
    }
    public String getDefaultm() {
        return defaultm;
    }

    public void setDefaultm(String defaultm) {
        this.defaultm=defaultm;
    }


}
