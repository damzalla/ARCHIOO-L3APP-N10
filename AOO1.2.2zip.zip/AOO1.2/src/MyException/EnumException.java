package MyException;

public enum EnumException {
    UTILISATION_DU_ZERO(1,"Utilisation d'un Zéro"),
    UTILISATION_DE_UN(2,"Ce n'est pas un nombre"),
    UTILISATION_DE_DEUX(3,"Opération inconnue");

    private final int code;
    private final String defaultm;



    EnumException(int code,String defaultm){
        this.code=code;
        this.defaultm=defaultm;
    }

    public int getCode() {
        return code;
    }
    public String getDefaultm() {
        return defaultm;
    }

    public static String getNameFromCode(int code) {
        for(EnumException e : EnumException.values()) {
            if (code ==e.code)
                return e.name();
        }
        return null;
    }
}
