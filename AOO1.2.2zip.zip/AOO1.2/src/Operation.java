import MyException.MonException;

public interface Operation {
    public double calculer(double a, double b) throws MonException;

}
