import MyException.MonException;

public class Calculator {

    public double calcul(String op, double a, double b) throws MonException {
        return CalculatorConf.getOperation(op).calculer(a,b);
    }

}
