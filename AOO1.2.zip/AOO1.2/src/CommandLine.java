import java.util.Scanner;

public class CommandLine {
    public CommandLine() {
        Scan();
    }

    private double a=0,b=0;
    private char op;
    public void Scan (){
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez a: ");
        a=sc.nextDouble();
        System.out.println("\nEntrez l'opérateur: ");
        op=sc.next().charAt(0);
        System.out.println("\nEntrez b: ");
        b=sc.nextDouble();
        Calculator.calculator(a,op,b);
    }
}
