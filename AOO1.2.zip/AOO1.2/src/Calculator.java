public class Calculator {

    public static void calculator(Double a, char op , Double b){
        if (op=='/'){
            Division.division(a,b);
        }

        if (op=='+'){
            Addition.addition(a,b);
        }

    }
}
