public class Division {
    public static int division(double a, double b) {
        if (b == 0) {
            System.out.println("Error division by 0");
            return -1;
        }
        System.out.println("Le Résultat: "+(a/b));
        return 0;
    }
}
