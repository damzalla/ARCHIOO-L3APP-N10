public class IHM {

    public IHM (){
        Lancer();
    }

    public static void Lancer (){
        CommandLine c = new CommandLine();
    }
}
