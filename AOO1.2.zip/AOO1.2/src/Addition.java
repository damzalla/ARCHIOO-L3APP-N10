public class Addition {
    public static int addition(double a, double b) {

        System.out.println("Le Résultat: "+(a+b));
        return 0;
    }
}
